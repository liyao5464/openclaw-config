#!/bin/bash
# GitHub上传脚本
# 使用方法：chmod +x upload-to-github.sh && ./upload-to-github.sh

# 配置
REPO_NAME="openclaw-config"
GITHUB_TOKEN="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"
GITHUB_USER="a546475226"

echo "🚀 开始上传OpenClaw配置到GitHub..."

# 1. 创建仓库
echo "📦 创建仓库 $REPO_NAME..."
curl -X POST \
  -H "Authorization: token $GITHUB_TOKEN" \
  -H "Accept: application/vnd.github.v3+json" \
  -d "{
    \"name\": \"$REPO_NAME\",
    \"description\": \"OpenClaw多分身配置 - 4个AI助手协同工作\",
    \"private\": false,
    \"auto_init\": true
  }" \
  https://api.github.com/user/repos

echo ""
echo "✅ 仓库创建完成！"
echo ""
echo "📝 接下来请手动上传文件："
echo "1. 访问: https://github.com/$GITHUB_USER/$REPO_NAME"
echo "2. 点击 'Add file' → 'Upload files'"
echo "3. 拖拽本目录所有文件"
echo "4. 填写提交信息: 'Initial commit: OpenClaw multi-agent config'"
echo "5. 点击 'Commit changes'"
echo ""
echo "📁 需要上传的文件："
ls -la /root/.openclaw/workspace/github-export/
